export class ProductInterest {
    id: number;
    product_id: number;
    product_name: string;
    name: string;
    email: string;
    message: string
}